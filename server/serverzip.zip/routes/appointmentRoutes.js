import express from 'express';
import rateLimit from 'express-rate-limit';
import { authenticate } from '../middleware/authenticate.js';
import {
  bookAppointment,
  getDoctorAppointments,
  getDoctorPendingAppointments,
  getPatientAppointments,
  approveAppointment,
  rejectAppointment,
  doctorApproveRejectAppointment,
  getAppointmentById,
  cancelAppointment,
  getAppointmentStats,
  getAllAppointments
} from '../controllers/Appointment.controller.js';

const router = express.Router();

// Rate limiter for appointment booking
const appointmentLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5,
  message: {
    success: false,
    message: 'Too many appointment requests. Please wait 15 minutes before trying again.',
  },
});

// Public route
router.post('/book', appointmentLimiter, bookAppointment);

// Doctor routes
router.get('/doctor/:doctorId', authenticate, getDoctorAppointments);
router.get('/doctor/:doctorId/pending', authenticate, getDoctorPendingAppointments);
router.get('/stats/:doctorId', authenticate, getAppointmentStats);
router.put('/:appointmentId/approve', authenticate, approveAppointment);
router.put('/:appointmentId/reject', authenticate, rejectAppointment);
router.put('/:appointmentId/approve-reject', authenticate, doctorApproveRejectAppointment);

// Patient routes
router.get('/patient/:patientEmail', authenticate, getPatientAppointments);
router.get('/:appointmentId', authenticate, getAppointmentById);
router.put('/:appointmentId/cancel', authenticate, cancelAppointment);

// Admin routes
router.get('/admin/all', authenticate, getAllAppointments);

export default router;
